package com.test.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mysql.jdbc.Statement;
import java.util.ArrayList;
import com.test.model.*;
import tools.ConnectionFactory;

public class RoomDao {
	public static String name="root";
	public static String password="root";
	public boolean existBID(int BID) throws ClassNotFoundException, SQLException
	{
		boolean flag;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
	    String sql="select BID from building where BID="+BID+";";
	    ResultSet rs = statement.executeQuery(sql);
	    if(rs.next() == false)//��BID
	    	flag= false;
	    else
	    	flag = true;
	    connection.closeConnection(statement, con);
	    return flag;
	}
	public boolean existRID(int BID, int RID) throws ClassNotFoundException, SQLException
	{
		boolean flag;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
	    String sql="select RID from room where RID="+RID+" and BID="+BID+";";
	    ResultSet rs = statement.executeQuery(sql);
	    if(rs.next() == false)//��RID
	    	flag = false;
	    else
	    	flag =  true;
	    connection.closeConnection(statement, con);
	    return flag;
	}
/*	public boolean isEmpty() throws ClassNotFoundException, SQLException
	{
		boolean flag;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
		ResultSet rs = null;
	    String sql="select * from room;";
	    rs = statement.executeQuery(sql);
	    if(rs.next() == false)
	    	flag = true;
	    else
	    	flag = false;
	    connection.closeConnection(statement, con);
	    return flag;
	}*/
	public int maxPerBID(int BID) throws ClassNotFoundException, SQLException
	{
		int result;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
		ResultSet rs = null;
	    String sql="select max(RID) from room where BID=" +BID+";";
	    rs = statement.executeQuery(sql);
	    if(rs.next() == false)
	    	result= 0;
	    else
	    	result = rs.getInt(1);
	    connection.closeConnection(statement, con);
	    return result;
	}
	public int countAll() throws ClassNotFoundException, SQLException
	{
		int result;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
		ResultSet rs = null;
	    String sql="select count(*) from room;";
	    rs = statement.executeQuery(sql);
	    if(rs.next() == false)
	    	result= 0;
	    else
	    	result= rs.getInt(1);
	    connection.closeConnection(statement, con);
	    return result;
	}
	public boolean insert(int BID, int RID) throws ClassNotFoundException, SQLException
	{
		boolean flag;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
		int result=0;
	    String sql="insert into room values("+BID+","+RID+");";
	    result = statement.executeUpdate(sql);
	    if(result == 1)//���ӳɹ�
	    	flag = true;
	    else
	    	flag = false;
	    connection.closeConnection(statement, con);
	    return flag;
	}
	public boolean delete(int BID, int RID) throws ClassNotFoundException, SQLException
	{
		
		boolean flag;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
		int result=-1;
		ArrayList<RoomModel> l = new ArrayList<RoomModel>();
	    //String sql="select * from room;";
	    //String sql="select * from room;";
		String tmp="SET FOREIGN_KEY_CHECKS=0;";
		statement.executeQuery(tmp);
	    String sql="delete  from room where BID="+BID+" and RID="+RID+";";
	   
	    result=statement.executeUpdate(sql);
	    if(result == 1)//���ӳɹ�
	    	flag = true;
	    else
	    	flag = false;
	    tmp="SET FOREIGN_KEY_CHECKS=1;";
		statement.executeQuery(tmp);
	    connection.closeConnection(statement, con);
	    return true;
		/*
		boolean flag;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
		int result=0;
		System.out.println("OKOKOK\n");
	   // String sql="delete  from room where BID="+BID+" and RID="+RID+";";
	    String sql="select * from room ;";
		statement.executeUpdate(sql);
		System.out.println("GUGUGG\n");
	    if(result == 1)//���ӳɹ�
	    	flag = true;
	    else
	    	flag = false;
	    connection.closeConnection(statement, con);
	    return flag;
	    */
	}
	@SuppressWarnings("null")
	public ArrayList<RoomModel> list() throws ClassNotFoundException, SQLException
	{
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
		ResultSet rs = null;
		ArrayList<RoomModel> l = new ArrayList<RoomModel>();
	    String sql="select * from room;";
	    rs = statement.executeQuery(sql);
	    while(rs.next())
	    {
	    	int bid = rs.getInt(1);
	    	int rid = rs.getInt(2);
	    	RoomModel rm = new RoomModel();
	    	rm.setBID(bid);
	    	rm.setRID(rid);
	    	l.add(rm);
	    }
	    connection.closeConnection(statement, con);
	    return l;
	}
	
	
	public ArrayList<RoomModel> queryInARoom(int BID) throws ClassNotFoundException, SQLException
	{
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
		ResultSet rs = null;
		ArrayList<RoomModel> l = new ArrayList<RoomModel>();
	    String sql="select * from room;";
	    rs = statement.executeQuery(sql);
	    while(rs.next())
	    {
	    	int bid = rs.getInt(1);
	    	int rid = rs.getInt(2);
	    	RoomModel rm = new RoomModel();
	    	rm.setBID(bid);
	    	rm.setRID(rid);
	    	if(BID==bid)l.add(rm);
	    }
	    connection.closeConnection(statement, con);
	    return l;
	}
}
