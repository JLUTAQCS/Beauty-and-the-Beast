package com.test.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mysql.jdbc.*;
import java.util.ArrayList;
import com.test.model.BuildingModel;
import tools.ConnectionFactory;;
public class BuildingDao {
	public static String name="root";
	public static String password="root";
	public BuildingModel query(int BID) throws ClassNotFoundException, SQLException
	{
		boolean flag;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
		ResultSet rs = null;
		BuildingModel l = new BuildingModel();
	    String sql="select BID from building where BID="+BID+";";
	    rs = statement.executeQuery(sql);
    	connection.closeConnection(statement, con);
    	return l;
	}
	public boolean existBID(int BID) throws ClassNotFoundException, SQLException
	{
		boolean flag;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
	    String sql="select BID from building where BID="+BID+";";
	    ResultSet rs = statement.executeQuery(sql);
	    if(rs.next())//BID�ظ�
	    	flag= true;
	    else
	    	flag = false;
	    connection.closeConnection(statement, con);
	    return flag;
	}
	public int maxBID() throws ClassNotFoundException, SQLException
	{
		int result;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
	    String sql="select max(BID) from building;";
	    ResultSet rs = statement.executeQuery(sql);
	    if(rs.next() == false)
	    	result= 0;
	    else
	    	result = rs.getInt(1);
	    connection.closeConnection(statement, con);
	    return result;
	}
	public int countAll() throws ClassNotFoundException, SQLException
	{
		int result;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
	    String sql="select count(*) from building;";
	    ResultSet rs = statement.executeQuery(sql);
	    if(rs.next() == false)
	    	result= 0;
	    else
	    	result= rs.getInt(1);
	    connection.closeConnection(statement, con);
	    return result;
	}
/*	public boolean isEmpty() throws ClassNotFoundException, SQLException
	{
		boolean flag;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
		ResultSet rs = null;
	    String sql="select * from building;";
	    rs = statement.executeQuery(sql);
	    if(rs.next() == false)
	    	flag = true;
	    else
	    	flag = false;
	    connection.closeConnection(statement, con);
	    return flag;
	}*/
	public boolean insert(int BID, String BName) throws ClassNotFoundException, SQLException
	{
		boolean flag;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
		int result=0;
	    String sql="insert into building values("+BID+",\""+BName+"\");";
	    result = statement.executeUpdate(sql);
	    if(result == 1)//���ӳɹ�
	    	flag = true;
	    else
	    	flag = false;
	    connection.closeConnection(statement, con);
	    return flag;
	}
	public boolean delete(int BID) throws ClassNotFoundException, SQLException
	{
		boolean flag;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
		int result=0;
	    String sql="delete from building where BID="+BID+";";
	    result = statement.executeUpdate(sql);
	    if(result == 1)//ɾ���ɹ�
	    	flag = true;
	    else
	    	flag = false;
	    connection.closeConnection(statement, con);
	    return flag;
	}
	@SuppressWarnings("null")
	public ArrayList<BuildingModel> list() throws ClassNotFoundException, SQLException
	{
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "123456");
		Statement statement = (Statement) con.createStatement();
		ResultSet rs = null;
		ArrayList<BuildingModel> l = new ArrayList<BuildingModel>();
	    String sql="select * from building;";
	    rs = statement.executeQuery(sql);
	    while(rs.next())
	    {
	    	int bid = rs.getInt(1);
	    	String bName = rs.getString(2);
	    	BuildingModel bm = new BuildingModel();
	    	bm.setBID(bid);
	    	bm.setBName(bName);
	    	l.add(bm);
	    }
	    connection.closeConnection(statement, con);
	    return l;
	}
}