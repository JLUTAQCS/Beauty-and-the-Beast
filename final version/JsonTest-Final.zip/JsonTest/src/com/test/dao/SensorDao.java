package com.test.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Statement;
import com.test.model.*;
import tools.ConnectionFactory;

public class SensorDao {
	
	public SensorModel query(String SID) throws ClassNotFoundException, SQLException
	{
		System.out.println("dao:"+SID);
		boolean flag;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
		SensorModel sm = new SensorModel();
		sm.setSID("-1");
		ResultSet rs = null;
		 String sql="select * from sensor";
		    rs = statement.executeQuery(sql);
		    int ct=0;
		    while(rs.next())
		    {
		    	ct++;
		    	int bid = rs.getInt("BID");
		    	int rid = rs.getInt("RID");
		    	String sid = rs.getString("SID");
		    	int type = rs.getInt("type");
		    	System.out.println("sid:"+sid+"\n"+"ct:"+ct+"\n");
		    	System.out.println("rid:"+rid+"\n"+"bid:"+bid+"\n");
		    	System.out.println("type:"+type+"\n"+"bid:"+bid+"\n");
		    	if(SID.equals(sid)) {
		    		sm.setBID(bid); 		
		    		sm.setRID(rid);   		
		    		sm.setSID(sid);		    		
		    		sm.settype(type);
		    		break;
		    	
		    	}
		    	
		    }
	   
    	connection.closeConnection(statement, con);
    	System.out.println("daoend:"+SID);
		return sm;
	}
	public boolean existBID(int BID) throws ClassNotFoundException, SQLException
	{
		boolean flag;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
	    String sql="select BID from building where BID="+BID+";";
	    ResultSet rs = statement.executeQuery(sql);
	    if(rs.next() == false)//BID������
	    	flag= false;
	    else
	    	flag = true;
	    connection.closeConnection(statement, con);
	    return flag;
	}
	public boolean existRID(int BID, int RID) throws ClassNotFoundException, SQLException
	{
		boolean flag;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
	    String sql="select RID from room where RID="+RID+" and BID="+BID+";";
	    ResultSet rs = statement.executeQuery(sql);
	    if(rs.next() == false)//RID������
	    	flag = false;
	    else
	    	flag =  true;
	    connection.closeConnection(statement, con);
	    return flag;
	}
	public boolean existSID(int BID,int RID,String SID) throws ClassNotFoundException, SQLException
	{
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
		String sql="select BID,RID,SID from sensor where BID="+BID+" and RID="+RID+" and SID="+SID+";";
	    ResultSet rs = statement.executeQuery(sql);
	    boolean flag;
	    if(rs.next() == false)//SID���ظ�
	    	flag= false;
	    else
	    	flag=true;
	    connection.closeConnection(statement, con);
	    return flag;
	}	
	public int countAll() throws ClassNotFoundException, SQLException
	{
		int result;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
		ResultSet rs = null;
	    String sql="select count(*) from sensor;";
	    rs = statement.executeQuery(sql);
	    if(rs.next() == false)
	    	result= 0;
	    else
	    	result= rs.getInt(1);
	    connection.closeConnection(statement, con);
	    return result;
	}
	/*public boolean insert(int BID, int RID) throws ClassNotFoundException, SQLException
	{
		boolean flag;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection(name, password);
		Statement statement = (Statement) con.createStatement();
		int result=0;
	    String sql="insert into room values("+BID+","+RID+");";
	    result = statement.executeUpdate(sql);
	    if(result == 1)//���ӳɹ�
	    	flag = true;
	    else
	    	flag = false;
	    connection.closeConnection(statement, con);
	    return flag;
	}*/
	public boolean insert(int BID,int RID,String SID,int type) throws ClassNotFoundException, SQLException
	{
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
		int result=0;
		boolean flag;
		System.out.println("HELLO\n");
		System.out.println("BID:"+BID);
		System.out.println("RID:"+RID);
		System.out.println("SID:"+SID);
		System.out.println("type:"+type);
		//String sql="SET FOREIGN_KEY_CHECHS =0";
		//statement.executeUpdate(sql);
		
		//String sql="insert into sensor values(\"7\",\"2\",\"S18\",\"2\");";
		
		 String sql="insert into sensor values("+BID+","+RID+","+SID+","+type+");";
		//String sql="insert into sensor values("+BID+",\""+RID+",\""+SID+",\""+type+"\");";
	    result = statement.executeUpdate(sql);

		//sql="SET FOREIGN_KEY_CHECHS =1";
		//statement.executeUpdate(sql);
	    
	    System.out.println("GOGOG\n");
	    if(result == 1)//���ӳɹ�
	    	flag=true;
	    else
	    	flag=false;
	    connection.closeConnection(statement, con);
	    return flag;
	}
	
	public boolean delete(int BID,int RID,String SID) throws ClassNotFoundException, SQLException
	{
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
		int result=0;
		boolean flag;
	    String sql="delete from sensor where BID="+BID+" and RID="+RID+" and SID="+SID+";";
	    result = statement.executeUpdate(sql);
	    if(result == 1)//���ӳɹ�
	    	flag=true;
	    else
	    	flag=false;
	    connection.closeConnection(statement, con);
	    return flag;
	}
	@SuppressWarnings("null")
	public ArrayList<SensorModel> query(int BID,int RID) throws ClassNotFoundException, SQLException
	{
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
		ResultSet rs = null;
		ArrayList<SensorModel> list = new ArrayList<SensorModel>();
	    String sql="select * from sensor";
	    rs = statement.executeQuery(sql);
	    while(rs.next())
	    {
	    	int bid = rs.getInt("BID");
	    	int rid = rs.getInt("RID");
	    	String sid = rs.getString("SID");
	    	int type = rs.getInt("type");
	    	SensorModel sm = new SensorModel();

	    	sm.setBID(bid);
	    	sm.setRID(rid);
	    	sm.setSID(sid);
	    	sm.settype(type);
	    	if(BID==bid&&RID==rid)list.add(sm);
	    }
	    connection.closeConnection(statement, con);
	    return list;
	}
}
