package com.test.model;

public class inputBuilding {
	int BID;
	public int getBID() {  
        return BID;  
    } 
}
