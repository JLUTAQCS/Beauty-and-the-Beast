package com.test.model;

public class outputdeviceinfo {
	int status;
	String LID;
 	int BID;
 	int RID;
 	

 	String setTime;

	public  outputdeviceinfo(int status,int BID,int RID,String LID,String setTime) {  
        this.status = status;  
        this.BID = BID;
        this.RID = RID;
        this.LID = LID;
       
        this.setTime = setTime;
    } 
}
