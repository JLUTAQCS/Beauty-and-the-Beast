package com.test.model;

public class inputHardware {
	public int BID;
	public int RID ;
	public int Ctrl;

	public int getBID() {  
        return BID;  
    }  
	public int getRID() {  
        return RID;  
    }  
	public int getCtrl() {
		return Ctrl;
	}
}
