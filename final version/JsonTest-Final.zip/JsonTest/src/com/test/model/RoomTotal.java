package com.test.model;

import java.util.List;

public class RoomTotal {
		int status;//�ɹ���־
	 	private int total; //��������  
	    private List<RoomModel> info; //�����б� 
	    public RoomTotal() {  
	    }  
	    public RoomTotal(int status,int total, List<RoomModel> info) {  
	        this.total = total;  
	        this.info= info;  
	    }  
	    public int getTotal() {  
	        return total;  
	    }  
	    public void setTotal(int total) {  
	        this.total = total;  
	    }  
	    public List<RoomModel> getinfo() {  
	        return info;  
	    }  
	    public void setRows(List<RoomModel> info) {  
	        this.info = info;  
	    }  
	      
}
