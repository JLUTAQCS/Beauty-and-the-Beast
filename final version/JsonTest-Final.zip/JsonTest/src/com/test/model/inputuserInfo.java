package com.test.model;

public class inputuserInfo {
	public int UID;
	int getUID() {
		return UID;
	}
}
