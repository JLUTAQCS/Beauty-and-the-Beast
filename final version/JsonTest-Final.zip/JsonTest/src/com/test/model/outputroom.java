package com.test.model;

import java.util.List;
public class outputroom{
		int status;//�ɹ���־
		List<BIDandRID> info;
	   
	    public outputroom(int status,List<BIDandRID> info) {  
	        this.status = status;  
	        this.info = info;  
	    }  
	      
}
