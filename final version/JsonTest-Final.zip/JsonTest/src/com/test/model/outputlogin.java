package com.test.model;

public class outputlogin {
	int status;//0�ɹ�,1ʧ��
	ClientModel user;
	public outputlogin(int status,ClientModel user) {
		this.status=status;
		this.user=user;
	}
}
