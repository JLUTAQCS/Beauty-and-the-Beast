package com.test.model;

public class inputroom {
	public String HID;
	String getHID() {
		return HID;
	}
}
