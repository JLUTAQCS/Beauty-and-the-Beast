package com.test.model;

public class BIDandRID {
	int BID;
	int RID;
	public BIDandRID(int BID,int RID) {
		this.BID=BID;
		this.RID=RID;
	}
}
