package com.test.model;

import java.util.List;
public class outputuserInfo{
		int status;
		int uid;
	 	String nickname;
	 	int authority; 
	    public  outputuserInfo(int status,int uid,String nickname,int authority) {  
	        this.status = status;  
	        this.uid = uid;
	        this.nickname = nickname;
	        this.authority = authority;
	    }  
	      
}
