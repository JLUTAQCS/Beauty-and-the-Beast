package com.test.model;

public class LightModel {
	private int BID;
	public int RID;
	public String LID;
	private String setTime;
	private int life;
	
	public int getBID() {
		return BID;
	}

	public void setBID(int bID) {
		BID = bID;
	}

	public int getRID() {
		return RID;
	}

	public void setRID(int rID) {
		RID = rID;
	}

	public String getLID() {
		return LID;
	}

	public void setLID(String lID) {
		LID = lID;
	}

	public String getSetTime() {
		return setTime;
	}

	public void setSetTime(String setTime) {
		this.setTime = setTime;
	}

	public int getLife() {
		return life;
	}

	public void setLife(int life) {
		this.life = life;
	}
}
