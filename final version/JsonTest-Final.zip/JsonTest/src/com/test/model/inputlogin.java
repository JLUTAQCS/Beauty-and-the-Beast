package com.test.model;

public class inputlogin {
	public int UID;
	public String password;
	public int getUID() {  
        return UID;  
    }  
	public String getpassword() {  
        return password;  
    }  
}
