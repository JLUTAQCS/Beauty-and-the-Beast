package com.test.model;

public class SensorModel {
	private int BID;
	public int RID;
	public String SID;
	private int type;
	public int getBID()
	{
		return BID;
	}
	public void setBID(int bid)
	{
		this.BID=bid;
	}
	public int getRID()
	{
		return RID;
	}
	public void setRID(int rid)
	{
		this.RID=rid;
	}
	public String getSID()
	{
		return SID;
	}
	public void setSID(String sid)
	{
		this.SID=sid;
	}
	public int gettype()
	{
		return type;
	}
	public void settype(int type)
	{
		this.type=type;
	}
	
}
