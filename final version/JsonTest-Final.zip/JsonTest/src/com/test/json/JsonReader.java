package com.test.json;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import javax.servlet.http.HttpServletRequest;
import net.sf.json.*;
 
public class JsonReader {
	public static JSONObject receivePost(HttpServletRequest request) throws IOException, UnsupportedEncodingException {
 
		// ��ȡ��������
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream(),"utf-8"));
		String line = null;
		StringBuilder sb = new StringBuilder();
		while ((line = br.readLine()) != null) {
			sb.append(line);
		}
		//��json�ַ���ת��Ϊjson����
		JSONObject json=JSONObject.fromObject(sb.toString());
		return json;
	}
	public static JSONObject getRequestPostJson(HttpServletRequest request) {
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					request.getInputStream()));
			String line = null;
			StringBuilder sb = new StringBuilder();
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}
 
			String reqBody = URLDecoder.decode(sb.toString(), "utf-8");
			JSONObject json = JSONObject.fromObject(reqBody);
			
			return json;
		} catch (Exception e) {
			
			return null;
		}
 
	}

}
