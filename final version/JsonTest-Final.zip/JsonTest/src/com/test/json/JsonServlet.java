package com.test.json;
import java.io.IOException;  
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.ArrayList;  
import java.util.List;  
  
import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import com.google.gson.Gson;
import com.test.model.BuildingModel;
import com.test.model.BuildingTotal;
import com.test.model.NewTotal;  
import com.test.model.News;
import com.test.model.RoomModel;
import com.test.service.BuildingService;
import com.test.service.RoomService;  
  
public class JsonServlet extends HttpServlet {  
  
    private static final long serialVersionUID = 1L;  
   
    @Override  
    protected void doGet(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {  

    	Gson gson = new Gson();
    	
    	
    	RoomService roomservice =new RoomService ();
    	
    	try {
    		roomservice.addRoom(1);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
    	
    	
    	
    	
    	String url = request.getRequestURI();
    	//String url="/123";
    	//JOptionPane.showMessageDialog(null, url,"标题",  JOptionPane.ERROR_MESSAGE);
        // 截取其中的方法名
        int number=url.lastIndexOf("/")+1;
        String methodName = url.substring(number,url.length());
        String methodName2 = methodName;
        Method method = null;
        //JOptionPane.showMessageDialog(null,  methodName,"标题", JOptionPane.ERROR_MESSAGE);
     
    	/* 
    	request.setCharacterEncoding("UTF-8");
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        try(BufferedReader reader = request.getReader()) {
            char[]buff = new char[1024];
            int len;
            while((len = reader.read(buff)) != -1) {
                sb.append(buff,0, len);
            }
            sb.append("}");
        }catch (IOException e) {
            e.printStackTrace();
        }
        Info info = gson.fromJson(sb.toString().trim(),Info.class);
    	*/
    	//添加部分

    	 gson = new Gson();
    	BuildingModel p = new BuildingModel();
    	
    	p.setBID(1);
    	p.setBName("DingXin");
    	BuildingService buildingservice =new BuildingService ();
    	
    	try {
			buildingservice.addBuilding(p.BName);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
    	
    	
    	
    	
    	//删除部分

    	/*
    	//Gson gson = new Gson();
    	BuildingModel p = new BuildingModel();
    	
    	p.setBID(1);
    	p.setBName("DingXin");
    	String str = gson.toJson(p);

    	BuildingModel b = gson.fromJson(str, BuildingModel.class);
    	
    	BuildingService buildingservice =new BuildingService ();
    	
    	try {
			buildingservice.deleteBuilding(b.BID);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	
    	*/
    	
    	//显示部分
        List<BuildingModel> buildinglist = new ArrayList<BuildingModel>(); 
       // BuildingService buildingservice =new BuildingService ();
        try {
			buildinglist= buildingservice.listAllBuildings();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  
        // 将数据封装到新闻总计类  
        BuildingTotal buildingtotal = new BuildingTotal(0,buildinglist.size(), buildinglist);  
  
        // 调用GSON jar工具包封装好的toJson方法，可直接生成JSON字符串  
        Gson gson2 = new Gson();  
        String json = gson2.toJson(buildingtotal);  
  
        // 输出到界面  
        System.out.println(json);  
        resp.setContentType("text/plain");  
        resp.setCharacterEncoding("gb2312");  
        PrintWriter out = new PrintWriter(resp.getOutputStream());  
        out.print(json);  
        out.flush();  
        // 更多Json转换使用请看JsonTest类  
    }  
  
    @Override  
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {  
        this.doGet(req, resp);  
    }  
  
}  