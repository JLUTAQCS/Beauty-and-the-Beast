package com.test.json;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;

public class pack {
	 // ���������  
	public void getpack(String json,HttpServletResponse response) throws IOException {
		System.out.println(json);  
    	response.setContentType("text/plain");  
    	response.setCharacterEncoding("gb2312");  
    	PrintWriter out = new PrintWriter(response.getOutputStream());  
    	out.print(json);  
    	out.flush();  
	}
}
