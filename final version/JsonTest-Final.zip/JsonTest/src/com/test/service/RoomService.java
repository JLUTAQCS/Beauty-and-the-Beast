package com.test.service;

import java.sql.SQLException;
import java.util.ArrayList;
import com.test.model.RoomModel;
import com.test.dao.RoomDao;
public class RoomService {
	@SuppressWarnings("null")
	private int roomNum;
	RoomDao rd = new RoomDao();
	public int addRoom(int BID) throws ClassNotFoundException, SQLException
	{
		if(rd.existBID(BID) == false)//BID������
			return 2;
		int RID = rd.maxPerBID(BID) + 1;
		while(rd.existRID(BID, RID))//RID�ظ�
			RID++;
		if(rd.insert(BID, RID))
			return 0;
		return 3;//���벻�ɹ�������ԭ��
	}
	@SuppressWarnings("null")
	public int deleteRoom(int BID, int RID) throws ClassNotFoundException, SQLException
	{
		System.out.println("GOGOG\n");
	
		if(rd.existBID(BID) == false)//BID������
			return 2;
		
		if(rd.existRID(BID, RID) == false)//RID������
			return 3;
		
		if(rd.delete(BID, RID))
			return 0;
		return 4;//ɾ�����ɹ�������ԭ��
		
	}
	@SuppressWarnings("null")
	public ArrayList<RoomModel> listAllRooms() throws ClassNotFoundException, SQLException
	{
		ArrayList<RoomModel> list = new ArrayList<RoomModel>();
		list = rd.list();
		if(list.isEmpty()) {//����Ϊ��
			setRoomNum(0);
			return null;
		}
		list =rd.list();
		setRoomNum(list.size());
		return list;
	}
	public ArrayList<RoomModel> queryRoomInABuilding(int BID) throws ClassNotFoundException, SQLException
	{
		ArrayList<RoomModel> list = new ArrayList<RoomModel>();
		list = rd.list();
		if(list.isEmpty()) {//����Ϊ��
			setRoomNum(0);
			return null;
		}
		list =rd.queryInARoom(BID);
		setRoomNum(list.size());
		return list;
	}
	public int getRoomNum() {
		return roomNum;
	}
	public void setRoomNum(int roomNum) {
		this.roomNum = roomNum;
	}
}
