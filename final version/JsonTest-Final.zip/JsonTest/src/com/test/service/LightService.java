package com.test.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.test.dao.LightDao;
import com.test.model.LightModel;


public class LightService {
		private int lightNum;
		LightDao ld = new LightDao();
		public LightModel queryLight(String LID) throws ClassNotFoundException, SQLException
		{	
			return ld.query(LID);
		}
		public int addLight(int BID,int RID,String LID,String setTime) throws ClassNotFoundException, SQLException
		{
			if(ld.existBID(BID) == false)
				return 2;
			if(ld.existRID(BID, RID)==false)
				return 3;
			/*String LID = 0;
			while(ld.existLID(BID, RID,LID))//LID�ظ�?????
				LID++;*/
			if(ld.insert(BID, RID, LID, setTime))
				return 0;
			return 4;
		}
		public int deleteLight(int BID,int RID,String LID) throws ClassNotFoundException, SQLException
		{
			if(ld.existBID(BID)==false)
				return 2;
			if(ld.existRID(BID, RID)==false)
				return 3;
			if(ld.existLID(BID, RID, LID)==false)
				return 4;
			if(ld.delete(BID, RID, LID))
				return 0;
			return 5;
		}
		
		public ArrayList<LightModel> queryLightInARoom(int BID,int RID) throws ClassNotFoundException, SQLException
		{
			ArrayList<LightModel> list = new ArrayList<LightModel>();
			list = ld.query(BID,RID);
			if(list.isEmpty()) {//����Ϊ��
				//setLightNum(0);
				//return null;
			}
			list =ld.query(BID,RID);
			setLightNum(list.size());
			return list;
		}
		public int getLightNum() {
			return lightNum;
		}
		public void setLightNum(int lightNum) {
			this.lightNum = lightNum;
		}
}
