package com.test.service;

import com.test.dao.ClientDao;

import java.sql.SQLException;
import java.util.List;

import com.test.model.BuildingModel;
import com.test.model.ClientModel;
public class ClientService {
	private ClientDao cdao=new ClientDao();
	public ClientModel queryClient(int UID) throws ClassNotFoundException, SQLException
	{
		List<ClientModel> list=(List<ClientModel>)cdao.select(UID);	
		ClientModel onemodel=list.get(0);
		return onemodel;
	}
	public int addaccount(int ID,String name,String password,int role) throws ClassNotFoundException, SQLException {
		ClientModel  onemodel=new ClientModel();
		onemodel.setUID(ID);
		onemodel.setName(name);
		onemodel.setPassword(password);
		onemodel.setRole(role);
		List<ClientModel> list=(List<ClientModel>)cdao.select(ID);
		if(list.size()==0) {
			cdao.insert(onemodel);
			return 0;//鎴愬姛
		}
		else {
			return 4;//閲嶅
		}
	}
	
	public int deleteaccount(int ID) throws ClassNotFoundException, SQLException {
		List<ClientModel> list=(List<ClientModel>)cdao.select(ID);
		if(list.size()==0) {
			return 2;//鐢ㄦ埛涓嶅瓨鍦�
		}
		else {
			cdao.delete(ID);
			return 0;//鎴愬姛
		}
	}
	public int changepassword(int ID,String password) throws ClassNotFoundException, SQLException {
		List<ClientModel> list=(List<ClientModel>)cdao.select(ID);
		if(list.size()==0) {
			return 2;//鐢ㄦ埛涓嶅瓨鍦�
		}
		ClientModel onemodel=list.get(0);
		onemodel.setPassword(password);
		cdao.update(onemodel);
		return 0;//success
		
	}
	public int loginAuthentication(int ID,String password) throws ClassNotFoundException, SQLException {
		List<ClientModel> list=(List<ClientModel>)cdao.select(ID);
		if(list.size()==0) {
			return 2;//鐢ㄦ埛涓嶅瓨鍦�
		}
		ClientModel onemodel=list.get(0);
		if(onemodel.getPassword().equals(password)) {
			return 0;//success
		}
		else {
			return 1;//瀵嗙爜閿欒
		}
	}
	
	public int emergencyLog(int option,String token,int uid,int id) throws ClassNotFoundException, SQLException {
		List<ClientModel> list=(List<ClientModel>)cdao.select(id);
		return 0;
	}
	
	public int modifyRole(int option,int uid,String token,int id,int priority) throws ClassNotFoundException, SQLException {
		List<ClientModel> list=(List<ClientModel>)cdao.select(id);
		return 0;
	}
	public int changeUserRole(int ID,int Role) throws ClassNotFoundException, SQLException {
		List<ClientModel> list=(List<ClientModel>)cdao.select(ID);
		if(list.size()==0) {
			return 2;//鐢ㄦ埛涓嶅瓨鍦�
		}
		ClientModel onemodel=list.get(0);
		onemodel.setRole(Role);
		cdao.update(onemodel);
	    return 0;//success
	}
	public Object listAllAccounts() throws ClassNotFoundException, SQLException {
		List<ClientModel> list=(List<ClientModel>)cdao.selectAll();
		return list;
	}
	public int modify(int ID,String name,String password,int role,int p) throws ClassNotFoundException, SQLException {return 1;}
	
}
